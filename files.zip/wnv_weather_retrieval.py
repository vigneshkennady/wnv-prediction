"""
=============================================================================
WNV Research Project — NOAA Weather Data Retrieval Pipeline
=============================================================================
Retrieves daily weather data for 6 target counties used in West Nile Virus
county-level prediction research.

Target Counties:
  - Larimer County, CO   (FIPS: 08069)
  - Boulder County, CO   (FIPS: 08013)
  - Dallas County, TX    (FIPS: 48113)
  - Maricopa County, AZ  (FIPS: 04013)
  - Cook County, IL      (FIPS: 17031)
  - Los Angeles County, CA (FIPS: 06037)

Variables Retrieved:
  - TAVG  : Average daily temperature (°C)
  - TMAX  : Maximum daily temperature (°C)
  - TMIN  : Minimum daily temperature (°C)
  - PRCP  : Daily precipitation (mm)
  - AWND  : Average daily wind speed (m/s)
  - DEWP  : Dew point temperature (°C)  — from ISD
  - RH    : Relative humidity (%)       — derived from TMAX and DEWP

Data Sources:
  - NOAA CDO v2 API (GHCND) : TAVG, TMAX, TMIN, PRCP, AWND
  - NOAA ISD Lite            : Hourly dew point → aggregated daily DEWP → RH

Usage:
  python wnv_weather_retrieval.py

Requirements:
  pip install requests pandas numpy tqdm

API Key: LBimaMFZNDcQkAKiOjwzokGzzmQSMkHZ
=============================================================================
"""

import os
import time
import gzip
import math
import logging
import requests
import numpy as np
import pandas as pd
from io import StringIO, BytesIO
from datetime import date, timedelta
from pathlib import Path
from typing import Optional

# ─── Configuration ────────────────────────────────────────────────────────────

API_TOKEN   = "LBimaMFZNDcQkAKiOjwzokGzzmQSMkHZ"
CDO_BASE    = "https://www.ncei.noaa.gov/cdo-web/api/v2"
ISD_BASE    = "https://www.ncei.noaa.gov/data/global-hourly/access"
NCEI_DATA   = "https://www.ncei.noaa.gov/access/services/data/v1"

# Date range: pull WNV-relevant years (mosquito season 2000–2024)
START_YEAR  = 2000
END_YEAR    = 2024

# Output directory
OUT_DIR = Path("wnv_weather_data")
OUT_DIR.mkdir(exist_ok=True)

# CDO API rate limit: 5 requests/second, 10,000 requests/day
API_DELAY   = 0.25   # seconds between requests
MAX_RETRIES = 5

# ─── County Definitions ───────────────────────────────────────────────────────

COUNTIES = {
    "Larimer_CO": {
        "fips"        : "FIPS:08069",
        "name"        : "Larimer County, CO",
        "state_fips"  : "08",
        "county_fips" : "069",
        # Best ASOS/ISD stations near Fort Collins
        "isd_stations": ["720533-99999", "726400-24018"],
    },
    "Boulder_CO": {
        "fips"        : "FIPS:08013",
        "name"        : "Boulder County, CO",
        "state_fips"  : "08",
        "county_fips" : "013",
        "isd_stations": ["726396-99999", "726400-24018"],
    },
    "Dallas_TX": {
        "fips"        : "FIPS:48113",
        "name"        : "Dallas County, TX",
        "state_fips"  : "48",
        "county_fips" : "113",
        "isd_stations": ["722590-03927", "722583-12960"],
    },
    "Maricopa_AZ": {
        "fips"        : "FIPS:04013",
        "name"        : "Maricopa County, AZ",
        "state_fips"  : "04",
        "county_fips" : "013",
        "isd_stations": ["722780-23183", "722784-99999"],
    },
    "Cook_IL": {
        "fips"        : "FIPS:17031",
        "name"        : "Cook County, IL",
        "state_fips"  : "17",
        "county_fips" : "031",
        "isd_stations": ["725300-94846", "725340-14819"],
    },
    "LosAngeles_CA": {
        "fips"        : "FIPS:06037",
        "name"        : "Los Angeles County, CA",
        "state_fips"  : "06",
        "county_fips" : "037",
        "isd_stations": ["722950-23174", "722956-03167"],
    },
}

GHCND_VARIABLES = ["TAVG", "TMAX", "TMIN", "PRCP", "AWND", "AWSP"]

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s  [%(levelname)s]  %(message)s",
    handlers=[
        logging.FileHandler(OUT_DIR / "retrieval.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# ─── Utility Functions ────────────────────────────────────────────────────────

def cdo_get(endpoint: str, params: dict, retries: int = MAX_RETRIES) -> dict:
    """Make a CDO API GET request with retry/backoff logic."""
    url     = f"{CDO_BASE}/{endpoint}"
    headers = {"token": API_TOKEN}
    for attempt in range(1, retries + 1):
        try:
            r = requests.get(url, headers=headers, params=params, timeout=30)
            if r.status_code == 200:
                time.sleep(API_DELAY)
                return r.json()
            elif r.status_code == 429:
                wait = 60 * attempt
                log.warning(f"Rate limited. Waiting {wait}s …")
                time.sleep(wait)
            else:
                log.warning(f"HTTP {r.status_code} on attempt {attempt}: {url}")
                time.sleep(2 ** attempt)
        except requests.RequestException as e:
            log.warning(f"Request error attempt {attempt}: {e}")
            time.sleep(2 ** attempt)
    log.error(f"All {retries} attempts failed for {url}")
    return {}


def dewpoint_to_rh(temp_c: float, dewp_c: float) -> float:
    """
    Compute relative humidity (%) from temperature and dew point using
    the August-Roche-Magnus approximation.

    Formula:  RH = 100 × exp(17.625 × Td / (243.04 + Td))
                       / exp(17.625 × T  / (243.04 + T ))

    Parameters
    ----------
    temp_c : float — air temperature in °C
    dewp_c : float — dew point temperature in °C

    Returns
    -------
    float — relative humidity in %
    """
    if pd.isna(temp_c) or pd.isna(dewp_c):
        return np.nan
    num   = math.exp(17.625 * dewp_c / (243.04 + dewp_c))
    denom = math.exp(17.625 * temp_c / (243.04 + temp_c))
    return round(100.0 * num / denom, 1)


def celsius_to_fahrenheit(c: float) -> float:
    return round(c * 9 / 5 + 32, 2) if not pd.isna(c) else np.nan


def tenths_to_full(val):
    """GHCND returns temperatures in tenths of °C; convert to °C."""
    return val / 10.0 if not pd.isna(val) else np.nan


# ─── Step 1: Find Best GHCND Stations for Each County ────────────────────────

def get_county_stations(county_key: str, county: dict,
                        start: str, end: str) -> pd.DataFrame:
    """
    Query CDO API for all GHCND stations within the county that have
    data coverage for our variables in the given period.
    Returns DataFrame sorted by data coverage (best first).
    """
    log.info(f"  [{county['name']}] Fetching station list …")
    params = {
        "datasetid"  : "GHCND",
        "locationid" : county["fips"],
        "datatypeid" : ",".join(GHCND_VARIABLES[:4]),  # TAVG,TMAX,TMIN,PRCP
        "startdate"  : start,
        "enddate"    : end,
        "limit"      : 1000,
        "sortfield"  : "datacoverage",
        "sortorder"  : "desc",
    }
    result   = cdo_get("stations", params)
    stations = result.get("results", [])
    if not stations:
        log.warning(f"  [{county['name']}] No stations found via county FIPS. "
                    f"Will fall back to known station IDs.")
    df = pd.DataFrame(stations) if stations else pd.DataFrame()
    log.info(f"  [{county['name']}] Found {len(df)} stations.")
    return df


# ─── Step 2: Pull GHCND Daily Data (CDO API) ──────────────────────────────────

def fetch_ghcnd_year(location_id: str, year: int,
                     county_name: str) -> pd.DataFrame:
    """
    Fetch all GHCND variables for one county-year via CDO v2 API.
    The API allows max 1 year of daily data per request and 1000 records/call.
    Handles pagination automatically.
    """
    start = f"{year}-01-01"
    end   = f"{year}-12-31"
    all_records = []
    offset = 1

    while True:
        params = {
            "datasetid"  : "GHCND",
            "locationid" : location_id,
            "datatypeid" : ",".join(GHCND_VARIABLES),
            "startdate"  : start,
            "enddate"    : end,
            "units"      : "metric",
            "limit"      : 1000,
            "offset"     : offset,
        }
        resp = cdo_get("data", params)
        records = resp.get("results", [])
        if not records:
            break
        all_records.extend(records)
        meta    = resp.get("metadata", {}).get("resultset", {})
        count   = meta.get("count", 0)
        limit   = meta.get("limit", 1000)
        off     = meta.get("offset", offset)
        if off + limit - 1 >= count:
            break
        offset += 1000

    if not all_records:
        return pd.DataFrame()

    df = pd.DataFrame(all_records)
    return df


def pivot_ghcnd(df_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Pivot raw CDO records (one row per datatype-per-day) into wide format
    (one row per day with each variable as a column).
    """
    if df_raw.empty:
        return pd.DataFrame()
    df = df_raw[["date", "datatype", "value", "station"]].copy()
    df["date"] = pd.to_datetime(df["date"]).dt.date

    # Keep only the most-complete station per day (station with most obs)
    station_counts = (df.groupby("station")["date"]
                        .nunique().reset_index()
                        .rename(columns={"date": "n_days"}))
    best_station = station_counts.sort_values("n_days", ascending=False).iloc[0]["station"]
    df = df[df["station"] == best_station]

    wide = df.pivot_table(
        index   = "date",
        columns = "datatype",
        values  = "value",
        aggfunc = "mean"   # average across duplicate reports if any
    ).reset_index()
    wide.columns.name = None

    # Ensure all expected columns exist
    for col in GHCND_VARIABLES:
        if col not in wide.columns:
            wide[col] = np.nan

    # Convert temperatures from tenths of °C → °C (CDO metric mode may
    # already be in °C, but guard just in case)
    for col in ["TAVG", "TMAX", "TMIN"]:
        if col in wide.columns:
            # If values look like they're in tenths (>100 commonly), divide
            sample = wide[col].dropna()
            if len(sample) > 0 and sample.abs().max() > 100:
                wide[col] = wide[col] / 10.0

    # AWND backup: use AWSP (average wind speed from PRES network) if AWND empty
    if "AWND" in wide.columns and "AWSP" in wide.columns:
        wide["AWND"] = wide["AWND"].fillna(wide["AWSP"])
    elif "AWSP" in wide.columns:
        wide["AWND"] = wide["AWSP"]

    wide["station_ghcnd"] = best_station
    return wide


# ─── Step 3: Pull ISD-Lite Hourly Data (for Dew Point → RH) ──────────────────

ISD_COLUMNS = [
    "date", "time", "air_temp", "dewpoint", "slp",
    "wind_dir", "wind_speed", "sky_cond", "precip_1h", "precip_6h"
]

def fetch_isd_station_year(station_id: str, year: int) -> pd.DataFrame:
    """
    Download one ISD-Lite file (gzip CSV) for a given station-year.
    Station ID format: USAF-WBAN  e.g. "722590-03927"
    """
    url = f"https://www.ncei.noaa.gov/pub/data/noaa/isd-lite/{year}/{station_id}-{year}.gz"
    try:
        r = requests.get(url, timeout=60)
        if r.status_code != 200:
            return pd.DataFrame()
        with gzip.open(BytesIO(r.content), "rt") as f:
            df = pd.read_fwf(
                f,
                widths  = [4, 3, 3, 3, 6, 6, 6, 6, 6, 6, 6, 6],
                header  = None,
                names   = ["year","month","day","hour","air_temp_x10",
                           "dewpoint_x10","slp_x10","wind_dir",
                           "wind_speed_x10","sky_cond","precip_1h_x10","precip_6h_x10"],
                na_values=["-9999"]
            )
        df["date"]       = pd.to_datetime(df[["year","month","day"]])
        df["air_temp"]   = df["air_temp_x10"]   / 10.0
        df["dewpoint"]   = df["dewpoint_x10"]   / 10.0
        df["wind_speed"] = df["wind_speed_x10"] / 10.0
        return df[["date","air_temp","dewpoint","wind_speed"]]
    except Exception as e:
        log.debug(f"ISD fetch failed for {station_id} {year}: {e}")
        return pd.DataFrame()


def daily_isd_aggregates(isd_df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate hourly ISD records to daily:
      - DEWP_mean  : mean daily dew point (°C)
      - DEWP_max   : max daily dew point
      - TAIR_mean  : mean daily air temp from ISD (backup/comparison)
    """
    if isd_df.empty:
        return pd.DataFrame()
    daily = (isd_df.groupby("date")
                   .agg(
                       DEWP_mean   = ("dewpoint",   "mean"),
                       DEWP_max    = ("dewpoint",   "max"),
                       TAIR_ISD    = ("air_temp",   "mean"),
                       WIND_ISD    = ("wind_speed", "mean"),
                   )
                   .reset_index())
    daily["date"] = daily["date"].dt.date
    return daily


# ─── Step 4: Merge GHCND + ISD, Compute RH ────────────────────────────────────

def merge_and_compute_rh(ghcnd_df: pd.DataFrame,
                          isd_df: pd.DataFrame) -> pd.DataFrame:
    """
    Merge GHCND daily data with ISD dew point aggregates.
    Derive RH from TAVG (or TAIR_ISD if TAVG missing) and DEWP_mean.
    """
    if ghcnd_df.empty and isd_df.empty:
        return pd.DataFrame()
    if ghcnd_df.empty:
        merged = isd_df.copy()
    elif isd_df.empty:
        merged = ghcnd_df.copy()
    else:
        merged = pd.merge(ghcnd_df, isd_df, on="date", how="outer")

    # Use TAVG for RH; fall back to TAIR_ISD if TAVG missing
    if "TAVG" in merged.columns and "TAIR_ISD" in merged.columns:
        temp_for_rh = merged["TAVG"].fillna(merged["TAIR_ISD"])
    elif "TAVG" in merged.columns:
        temp_for_rh = merged["TAVG"]
    elif "TAIR_ISD" in merged.columns:
        temp_for_rh = merged["TAIR_ISD"]
    else:
        temp_for_rh = pd.Series([np.nan] * len(merged))

    # Compute RH
    if "DEWP_mean" in merged.columns:
        merged["RH"] = [
            dewpoint_to_rh(t, d)
            for t, d in zip(temp_for_rh, merged["DEWP_mean"])
        ]
    else:
        merged["RH"] = np.nan

    # Prefer GHCND AWND for wind; fall back to ISD wind
    if "AWND" in merged.columns and "WIND_ISD" in merged.columns:
        merged["WIND"] = merged["AWND"].fillna(merged["WIND_ISD"])
    elif "AWND" in merged.columns:
        merged["WIND"] = merged["AWND"]
    elif "WIND_ISD" in merged.columns:
        merged["WIND"] = merged["WIND_ISD"]
    else:
        merged["WIND"] = np.nan

    return merged


# ─── Step 5: Final Clean & Column Selection ───────────────────────────────────

FINAL_COLUMNS = [
    "date", "county", "state", "fips",
    "TAVG", "TMAX", "TMIN", "PRCP", "WIND",
    "DEWP_mean", "RH",
    "station_ghcnd"
]

def clean_final(df: pd.DataFrame, county_key: str,
                county: dict) -> pd.DataFrame:
    """Standardize column names, add metadata, clip extreme values."""
    df = df.copy()
    df["county"] = county["name"].split(",")[0]
    df["state"]  = county["name"].split(", ")[1] if ", " in county["name"] else ""
    df["fips"]   = county["fips"].replace("FIPS:", "")
    df["date"]   = pd.to_datetime(df["date"])

    # Clip clearly erroneous values
    for col, lo, hi in [
        ("TAVG", -60, 60), ("TMAX", -60, 70), ("TMIN", -60, 60),
        ("PRCP",   0, 1000), ("WIND", 0, 80),
        ("RH",     0, 100), ("DEWP_mean", -60, 40),
    ]:
        if col in df.columns:
            df[col] = df[col].clip(lo, hi)

    # Round
    for col in ["TAVG","TMAX","TMIN","DEWP_mean"]:
        if col in df.columns:
            df[col] = df[col].round(1)
    for col in ["PRCP","WIND","RH"]:
        if col in df.columns:
            df[col] = df[col].round(2)

    # Ensure required columns exist
    for col in FINAL_COLUMNS:
        if col not in df.columns:
            df[col] = np.nan

    df = df.sort_values("date").reset_index(drop=True)
    return df[FINAL_COLUMNS]


# ─── Main Orchestrator ────────────────────────────────────────────────────────

def process_county(county_key: str, county: dict) -> pd.DataFrame:
    """
    Full pipeline for one county:
      1. Discover best GHCND stations
      2. Pull GHCND year-by-year
      3. Pull ISD-Lite year-by-year for humidity/dew point
      4. Merge and compute RH
      5. Clean and return final DataFrame
    """
    log.info(f"\n{'='*60}")
    log.info(f"Processing: {county['name']}")
    log.info(f"{'='*60}")

    # Output cache path — resume-safe
    cache_path = OUT_DIR / f"{county_key}_raw.parquet"
    if cache_path.exists():
        log.info(f"  Cache found at {cache_path}. Loading …")
        return pd.read_parquet(cache_path)

    all_years_dfs = []

    for year in range(START_YEAR, END_YEAR + 1):
        log.info(f"  Year {year} …")
        start_str = f"{year}-01-01"
        end_str   = f"{year}-12-31"

        # ── GHCND Data ──
        raw_ghcnd = fetch_ghcnd_year(county["fips"], year, county["name"])
        if raw_ghcnd.empty:
            log.warning(f"    No GHCND data for {county['name']} {year}.")
            ghcnd_daily = pd.DataFrame()
        else:
            ghcnd_daily = pivot_ghcnd(raw_ghcnd)

        # ── ISD-Lite Data (dew point → RH) ──
        isd_frames = []
        for sid in county.get("isd_stations", []):
            isd_yr = fetch_isd_station_year(sid, year)
            if not isd_yr.empty:
                isd_frames.append(isd_yr)
        if isd_frames:
            isd_hourly = pd.concat(isd_frames, ignore_index=True)
            # Average across stations for same date-hour
            isd_hourly = (isd_hourly.groupby("date")
                                    .agg(dewpoint   = ("dewpoint",   "mean"),
                                         air_temp   = ("air_temp",   "mean"),
                                         wind_speed = ("wind_speed", "mean"))
                                    .reset_index())
            isd_hourly.rename(columns={"dewpoint":"dewpoint", "air_temp":"air_temp",
                                       "wind_speed":"wind_speed"}, inplace=True)
            # Re-aggregate to daily
            isd_daily = pd.DataFrame({
                "date"     : isd_hourly["date"],
                "DEWP_mean": isd_hourly["dewpoint"],
                "TAIR_ISD" : isd_hourly["air_temp"],
                "WIND_ISD" : isd_hourly["wind_speed"],
            })
        else:
            isd_daily = pd.DataFrame()

        # ── Merge ──
        year_df = merge_and_compute_rh(ghcnd_daily, isd_daily)
        if not year_df.empty:
            year_df["year"] = year
            all_years_dfs.append(year_df)

    if not all_years_dfs:
        log.error(f"  No data collected for {county['name']}!")
        return pd.DataFrame()

    combined = pd.concat(all_years_dfs, ignore_index=True)
    final    = clean_final(combined, county_key, county)

    # Save parquet cache
    final.to_parquet(cache_path, index=False)
    log.info(f"  Saved {len(final):,} daily records → {cache_path}")
    return final


def compute_summary_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Compute annual summary statistics per county for QA."""
    numeric = ["TAVG", "TMAX", "TMIN", "PRCP", "WIND", "RH"]
    avail = [c for c in numeric if c in df.columns]
    df["year"] = pd.to_datetime(df["date"]).dt.year
    summary = (df.groupby(["county", "state", "fips", "year"])[avail]
                 .agg(["mean", "min", "max",
                        lambda x: x.isna().sum()])
                 .round(2))
    summary.columns = ["_".join(c).strip() for c in summary.columns]
    # Rename lambda columns
    summary.columns = [
        c.replace("<lambda_0>", "missing") for c in summary.columns
    ]
    return summary.reset_index()


# ─── Run ──────────────────────────────────────────────────────────────────────

def main():
    log.info("WNV Weather Data Retrieval Pipeline Starting …")
    log.info(f"Date range: {START_YEAR}–{END_YEAR}")
    log.info(f"Output dir: {OUT_DIR.resolve()}")

    all_county_dfs = []

    for county_key, county in COUNTIES.items():
        try:
            df = process_county(county_key, county)
            if not df.empty:
                all_county_dfs.append(df)
                # Save individual county CSV
                csv_path = OUT_DIR / f"{county_key}_{START_YEAR}_{END_YEAR}.csv"
                df.to_csv(csv_path, index=False)
                log.info(f"  CSV saved → {csv_path}")
        except Exception as e:
            log.error(f"Failed to process {county['name']}: {e}", exc_info=True)

    if not all_county_dfs:
        log.error("No data collected for any county. Exiting.")
        return

    # ── Combined output ──
    combined_all = pd.concat(all_county_dfs, ignore_index=True)
    combined_path = OUT_DIR / f"ALL_COUNTIES_weather_{START_YEAR}_{END_YEAR}.csv"
    combined_all.to_csv(combined_path, index=False)
    log.info(f"\nCombined dataset saved → {combined_path}")
    log.info(f"Total records: {len(combined_all):,}")
    log.info(f"Date range:    {combined_all['date'].min()} to {combined_all['date'].max()}")
    log.info(f"Counties:      {combined_all['county'].unique().tolist()}")

    # ── Summary / QA stats ──
    summary = compute_summary_stats(combined_all)
    summary_path = OUT_DIR / "summary_stats.csv"
    summary.to_csv(summary_path, index=False)
    log.info(f"Summary stats saved → {summary_path}")

    # Print data coverage report
    print("\n" + "="*70)
    print("DATA COVERAGE REPORT")
    print("="*70)
    for county_name, grp in combined_all.groupby("county"):
        n_total    = len(grp)
        n_complete = grp[["TAVG","TMAX","TMIN","PRCP","WIND","RH"]].notna().all(axis=1).sum()
        pct = round(100 * n_complete / n_total, 1) if n_total > 0 else 0
        print(f"  {county_name:<25} {n_total:>6} days | "
              f"Full-variable rows: {n_complete:>5} ({pct}%)")
        for col in ["TAVG","TMAX","TMIN","PRCP","WIND","RH"]:
            if col in grp.columns:
                miss = grp[col].isna().sum()
                pct_miss = round(100 * miss / n_total, 1)
                print(f"      {col:<8}  missing: {miss:>4} ({pct_miss}%)")
    print("="*70)
    print(f"\nAll files written to: {OUT_DIR.resolve()}/")


if __name__ == "__main__":
    main()
